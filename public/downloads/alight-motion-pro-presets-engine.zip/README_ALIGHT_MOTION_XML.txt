BADARSH COMMERCIAL DIGITAL ASSET LICENSE
Website: https://www.badarsh.com
Support: hello@badarsh.com

1. Permitted Uses: Unlimited personal & commercial client projects (YouTube, Instagram Reels, ads, podcasts, client websites).
2. Prohibited Uses: Reselling, redistributing, or sharing raw unpacked files as your own digital store bundle.

Import the .xml files directly into Alight Motion via Project -> Import XML.
