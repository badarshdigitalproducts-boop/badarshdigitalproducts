BADARSH COMMERCIAL DIGITAL ASSET LICENSE
Website: https://www.badarsh.com
Support: hello@badarsh.com

1. Permitted Uses: Unlimited personal & commercial client projects (YouTube, Instagram Reels, ads, podcasts, client websites).
2. Prohibited Uses: Reselling, redistributing, or sharing raw unpacked files as your own digital store bundle.

Official VN (.cube) LUTs, 4K export guide, and Beat-Sync SFX starter files.
Install VN cleanly from Apple App Store / Google Play and import the LUTs folder.
